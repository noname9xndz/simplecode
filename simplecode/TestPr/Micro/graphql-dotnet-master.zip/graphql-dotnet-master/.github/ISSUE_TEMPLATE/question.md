---
name: Question
about: Usage question or discussion about GraphQL .NET.
---

<!--
  To make it easier for us to help you, please include as much useful information as possible.

  Useful Links:
  - Documentation: https://graphql-dotnet.github.io/

  GraphQL .NET has community support channels, try asking your question on:

  - Gitter: https://gitter.im/graphql-dotnet/graphql-dotnet
  - Stack Overflow: https://stackoverflow.com/questions/tagged/graphql-dotnet

  Before opening a new issue, please search existing issues https://github.com/graphql-dotnet/graphql-dotnet/issues
-->

## Summary

## Relevant information

<!-- Provide as much useful information as you can -->

### Environment (if relevant)

<!--
  Version, OS, Server Architecture, etc.
-->
