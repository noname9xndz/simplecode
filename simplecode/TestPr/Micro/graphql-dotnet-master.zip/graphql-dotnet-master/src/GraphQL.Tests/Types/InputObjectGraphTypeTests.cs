using System;
using GraphQL.Types;
using Shouldly;
using Xunit;

namespace GraphQL.Tests.Types
{
    public class InputObjectGraphTypeTests
    {
        [Fact]
        public void should_throw_an_exception_if_input_object_graph_type_contains_object_graph_type_field()
        {
            var type = new InputObjectGraphType();
            var exception = Should.Throw<ArgumentOutOfRangeException>(() => type.Field<ObjectGraphType>().Name("test"));

            exception.Message.ShouldContain("Input type 'InputObject' can have fields only of input types: ScalarGraphType, EnumerationGraphType or IInputObjectGraphType.");
        }

        [Fact]
        public void should_throw_an_exception_if_object_graph_type_contains_Input_object_graph_type_field()
        {
            var type = new ObjectGraphType();
            var exception = Should.Throw<ArgumentOutOfRangeException>(() => type.Field<InputObjectGraphType>().Name("test"));
            exception.Message.ShouldContain("Output type 'Object' can have fields only of output types: ScalarGraphType, ObjectGraphType, InterfaceGraphType, UnionGraphType or EnumerationGraphType.");
        }
    }
}
