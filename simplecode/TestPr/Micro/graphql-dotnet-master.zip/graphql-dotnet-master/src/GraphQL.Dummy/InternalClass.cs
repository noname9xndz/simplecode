namespace GraphQL.Dummy
{
    internal class InternalClass
    {
    }
}
