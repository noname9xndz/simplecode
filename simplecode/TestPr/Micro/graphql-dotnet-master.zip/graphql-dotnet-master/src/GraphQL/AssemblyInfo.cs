﻿[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("GraphQL.Tests")]
