namespace GraphQL.Language.AST
{
    public interface ISelection : INode
    {
    }
}
