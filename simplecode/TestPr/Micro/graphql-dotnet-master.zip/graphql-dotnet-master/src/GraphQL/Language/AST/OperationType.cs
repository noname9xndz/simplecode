namespace GraphQL.Language.AST
{
    public enum OperationType
    {
        Query,
        Mutation,
        Subscription
    }
}
