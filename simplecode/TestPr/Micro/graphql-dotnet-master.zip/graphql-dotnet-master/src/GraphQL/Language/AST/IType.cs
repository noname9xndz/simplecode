﻿namespace GraphQL.Language.AST
{
    public interface IType : INode
    {
    }
}
