﻿namespace GraphQL.Language.AST
{
    public interface IDefinition : INode
    {
    }
}
