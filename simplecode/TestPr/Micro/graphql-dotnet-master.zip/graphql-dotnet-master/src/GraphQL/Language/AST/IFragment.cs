namespace GraphQL.Language.AST
{
    public interface IFragment : ISelection
    {
    }
}
