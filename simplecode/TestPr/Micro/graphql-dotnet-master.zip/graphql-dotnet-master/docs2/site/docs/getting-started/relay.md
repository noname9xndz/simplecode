# Relay

The core project provides a few classes to help implement Facebook's [Relay](https://facebook.github.io/relay/).  You can find more types and helpers in the [GraphQL .NET Relay project](https://github.com/graphql-dotnet/relay).

Example needed...
