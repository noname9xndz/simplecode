# GraphQL .NET Docs

Some code + setup inspired & borrowed from https://github.com/brainhubeu/gatsby-docs-kit

To run the docs:

```
yarn
yarn develop
```

# Publishing

Publishing documentation requires:

* write access to https://github.com/graphql-dotnet/graphql-dotnet.github.io
* running node on version v10.22.0 (v12.x seems to currently have issues)

```
yarn deploy
```
