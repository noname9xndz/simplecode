namespace GraphQL.Client.Abstractions.Websocket
{
    public enum GraphQLWebsocketConnectionState
    {
        Disconnected,

        Connecting,

        Connected
    }
}
