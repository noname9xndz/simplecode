namespace GraphQL.Client.Tests.Common.Chat.Schema
{
    public class MessageFrom
    {
        public string Id { get; set; }

        public string DisplayName { get; set; }
    }
}
